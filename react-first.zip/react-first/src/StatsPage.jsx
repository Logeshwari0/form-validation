import React from 'react';

function StatsPage({ users, goBack }) {
  const maleCount = users.filter(u => u.gender === 'Male').length;
  const femaleCount = users.filter(u => u.gender === 'Female').length;
  const adultCount = users.filter(u => u.age >= 18).length;
  const childCount = users.filter(u => u.age < 18).length;

  return (
    <div class="empty">
    <div style={{ padding: '20px' }}>
      <h2>📊 User Stats Summary</h2>
      <p>Total Users: {users.length}</p>
      <p>👨‍🦱 Male: {maleCount}</p>
      <p>👩 Female: {femaleCount}</p>
      <p>🧑 Adults (18+): {adultCount}</p>
      <p>👶 Children ({"<"}18): {childCount}</p>

      <h4> All Users:</h4>
      <ul>
        {users.map((u, i) => (
          <li key={i}>
            {u.name} - {u.gender} - Age: {u.age}
          </li>
        ))}
      </ul>

      <br />
      <button onClick={goBack}>🔙 Back to Form</button>
    </div>
    </div>
  );
}

export default StatsPage;