import React, { useState } from 'react';

function UserFormPage({ users, setUsers, goToStats }) {
  const [formData, setFormData] = useState({
    name: '',
    gender: '',
    age: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleAddUser = () => {
    if (formData.name && formData.gender && formData.age) {
      const newUser = { ...formData, age: Number(formData.age) };
      setUsers([...users, newUser]);
      setFormData({ name: '', gender: '', age: '' });
    }
  };

  return (
    <div  class ="hello" style={{ padding: '20px' }}>
      <h2> User Entry Form</h2>
       <div>
      <input
        type="text"
        name="name"
        placeholder="Enter Name"
        value={formData.name}
        onChange={handleChange}
      />
      <br /><br />

      <label>
        <input
          type="radio"
          name="gender"
          value="Male"
          checked={formData.gender === 'Male'}
          onChange={handleChange}
        /> Male
      </label>
      <label style={{ marginLeft: '10px' }}>
        <input
          type="radio"
          name="gender"
          value="Female"
          checked={formData.gender === 'Female'}
          onChange={handleChange}
        /> Female
      </label>
      <br /><br />

      <input
        type="number"
        name="age"
        placeholder="Enter Age"
        value={formData.age}
        onChange={handleChange}
      />
      <br /><br />

      <button onClick={handleAddUser}>➕ Add User</button>
      <br /><br />

      <button onClick={goToStats} disabled={users.length === 0}>📊 View Stats</button>
       <br/>
       <br/>
      <h4>📝 Users List:</h4>
      <ul>
        {users.map((u, i) => (
          <li key={i}>{u.name} - {u.gender} - Age: {u.age}</li>
        ))}
      </ul>
    </div>
    </div>
  );
}

export default UserFormPage;